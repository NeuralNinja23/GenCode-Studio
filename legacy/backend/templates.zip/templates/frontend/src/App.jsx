import React, { useEffect, useState } from "react";
import { getHealthStatus } from "./lib/api";

function App() {
    const [health, setHealth] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        async function fetchHealth() {
            try {
                setLoading(true);
                const status = await getHealthStatus();
                setHealth(status);
            } catch (err) {
                console.error(err);
                setError("Failed to reach backend");
            } finally {
                setLoading(false);
            }
        }

        fetchHealth();
    }, []);

    return (
        <div
            style={{
                minHeight: "100vh",
                padding: "2rem",
                fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
                background: "#050816",
                color: "#f9fafb"
            }}
        >
            <main
                style={{
                    maxWidth: "640px",
                    margin: "0 auto",
                    padding: "2rem",
                    borderRadius: "1.5rem",
                    background: "rgba(15, 23, 42, 0.9)",
                    boxShadow: "0 20px 40px rgba(0,0,0,0.4)",
                    border: "1px solid rgba(148, 163, 184, 0.3)"
                }}
            >
                <h1 style={{ fontSize: "1.8rem", marginBottom: "0.5rem" }}>
                    GenCode Frontend Template
                </h1>
                <p style={{ marginBottom: "1.5rem", color: "#9ca3af" }}>
                    This is the golden React/Vite template wired to your backend.
                </p>

                <section
                    style={{
                        padding: "1rem 1.25rem",
                        borderRadius: "0.9rem",
                        background: "rgba(15, 23, 42, 0.9)",
                        border: "1px solid rgba(55, 65, 81, 0.8)"
                    }}
                >
                    <h2
                        style={{
                            fontSize: "1.1rem",
                            marginBottom: "0.5rem",
                            color: "#e5e7eb"
                        }}
                    >
                        Backend Health
                    </h2>

                    {loading && <p>Checking backend health…</p>}

                    {!loading && error && (
                        <p style={{ color: "#f87171" }}>{error}</p>
                    )}

                    {!loading && !error && health && (
                        <pre
                            style={{
                                marginTop: "0.5rem",
                                padding: "0.75rem",
                                borderRadius: "0.75rem",
                                background: "rgba(15, 23, 42, 0.9)",
                                border: "1px solid rgba(55,65,81,0.8)",
                                fontSize: "0.9rem"
                            }}
                        >
                            {JSON.stringify(health, null, 2)}
                        </pre>
                    )}
                </section>

                <section style={{ marginTop: "1.5rem", fontSize: "0.9rem" }}>
                    <p style={{ color: "#9ca3af" }}>
                        Backend URL is controlled via{" "}
                        <code style={{ fontFamily: "monospace" }}>VITE_API_BASE_URL</code>{" "}
                        (defaults to <code>http://localhost:8000</code>).
                    </p>
                </section>
            </main>
        </div>
    );
}

export default App;
