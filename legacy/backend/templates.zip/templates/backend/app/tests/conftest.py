from __future__ import annotations

from typing import AsyncIterator

import pytest
from httpx import AsyncClient

from app.main import app


@pytest.fixture(scope="session")
def anyio_backend() -> str:
    """
    Configure pytest-anyio to use asyncio.
    """
    return "asyncio"


@pytest.fixture()
async def async_client() -> AsyncIterator[AsyncClient]:
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client
