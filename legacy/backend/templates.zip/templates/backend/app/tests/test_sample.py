from __future__ import annotations

from httpx import AsyncClient


async def test_health_endpoint(async_client: AsyncClient) -> None:
    response = await async_client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


async def test_example_ping(async_client: AsyncClient) -> None:
    response = await async_client.get("/api/example/ping")
    assert response.status_code == 200
    assert response.json().get("message") == "pong"


async def test_example_echo(async_client: AsyncClient) -> None:
    msg = "hello-world"
    response = await async_client.get(f"/api/example/echo?message={msg}")
    assert response.status_code == 200
    assert response.json().get("echo") == msg
