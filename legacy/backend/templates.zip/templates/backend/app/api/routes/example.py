from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, HTTPException

from app.schemas.example import ExampleCreate, ExampleRead
from app.services.example_service import ExampleService

router = APIRouter(
    prefix="/example",
    tags=["example"],
)

# Single in-memory service instance (for template)
service = ExampleService()


@router.get("/ping", summary="Example ping endpoint")
async def example_ping() -> dict[str, str]:
    return {"message": "pong"}


@router.get("/echo", summary="Echo a message back to the client")
async def echo(message: str) -> dict[str, str]:
    return {"echo": message}


@router.post("/", response_model=ExampleRead, summary="Create an example")
async def create_example(payload: ExampleCreate) -> ExampleRead:
    return await service.create_example(payload)


@router.get("/", response_model=List[ExampleRead], summary="List examples")
async def list_examples() -> List[ExampleRead]:
    return await service.list_examples()


@router.get("/{example_id}", response_model=ExampleRead, summary="Get example by ID")
async def get_example(example_id: str) -> ExampleRead:
    example = await service.get_example(example_id)
    if example is None:
        raise HTTPException(status_code=404, detail="Example not found")
    return example


@router.delete("/{example_id}", summary="Delete example by ID")
async def delete_example(example_id: str) -> dict[str, bool]:
    deleted = await service.delete_example(example_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Example not found")
    return {"deleted": True}
