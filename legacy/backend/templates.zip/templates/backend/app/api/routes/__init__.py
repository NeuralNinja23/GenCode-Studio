from __future__ import annotations

from fastapi import APIRouter

from .example import router as example_router

router = APIRouter()

# Mount feature routers here
router.include_router(example_router)
