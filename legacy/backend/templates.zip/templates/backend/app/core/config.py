from __future__ import annotations

from .settings import Settings, get_settings

settings: Settings = get_settings()
