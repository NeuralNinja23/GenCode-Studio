from __future__ import annotations

from functools import lru_cache
from typing import Literal, Optional

from pydantic import AnyHttpUrl, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Global application settings.
    """

    # Environment
    ENV: Literal["local", "dev", "staging", "prod"] = "local"
    DEBUG: bool = True

    # App meta
    APP_NAME: str = "GenCode Backend"
    VERSION: str = "0.1.0"

    # CORS
    BACKEND_CORS_ORIGINS: list[AnyHttpUrl] = Field(default_factory=list)

    # API prefix
    API_PREFIX: str = "/api"

    # Database URL (optional)
    DATABASE_URL: Optional[str] = None

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """
    Cached settings accessor.
    """
    return Settings()
