from __future__ import annotations

from .example_service import ExampleService  # noqa: F401
