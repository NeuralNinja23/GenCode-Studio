from __future__ import annotations

from datetime import datetime
from typing import Dict

from app.schemas.example import ExampleCreate, ExampleRead


class ExampleService:
    """
    Simple in-memory Example service.
    """

    def __init__(self) -> None:
        self._store: Dict[str, ExampleRead] = {}

    async def create_example(self, payload: ExampleCreate) -> ExampleRead:
        example_id = str(len(self._store) + 1)
        example = ExampleRead(
            id=example_id,
            name=payload.name,
            description=payload.description,
            created_at=datetime.utcnow(),
        )
        self._store[example_id] = example
        return example

    async def get_example(self, example_id: str) -> ExampleRead | None:
        return self._store.get(example_id)

    async def list_examples(self) -> list[ExampleRead]:
        return list(self._store.values())

    async def delete_example(self, example_id: str) -> bool:
        if example_id in self._store:
            del self._store[example_id]
            return True
        return False

    async def clear(self) -> None:
        self._store.clear()
