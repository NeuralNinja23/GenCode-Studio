from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class ExampleBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = Field(default=None, max_length=500)


class ExampleCreate(ExampleBase):
    pass


class ExampleRead(ExampleBase):
    id: str = Field(..., description="Unique identifier of the example")
    created_at: datetime = Field(..., description="Creation timestamp")
