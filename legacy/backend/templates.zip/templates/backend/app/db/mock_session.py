from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any, Dict


class MockSession:
    """
    Simple in-memory stand-in for a database session.
    """

    def __init__(self) -> None:
        self._store: Dict[str, Any] = {}

    async def get(self, key: str) -> Any:
        return self._store.get(key)

    async def set(self, key: str, value: Any) -> None:
        self._store[key] = value

    async def delete(self, key: str) -> None:
        self._store.pop(key, None)

    async def clear(self) -> None:
        self._store.clear()


async def get_mock_db() -> AsyncIterator[MockSession]:
    session = MockSession()
    try:
        yield session
    finally:
        await session.clear()
